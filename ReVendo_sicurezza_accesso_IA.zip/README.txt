# ReVendo — IA, account e PWA preparata per Android

## Cosa contiene
- Mantiene la grafica attuale del sito.
- Account e assistente IA lato server (la ricerca IA richiede una chiave API OpenAI).
- CSS e JavaScript separati, Content Security Policy più restrittiva, Helmet e rate limit.
- Manifest PWA, service worker network-only e pulsante di installazione.
- Icone temporanee generiche: sostituiscile con il tuo logo prima del lancio.

## Avvio locale
Richiede Node.js 18 o successivo. Esegui `npm install`, copia `.env.example` in `.env`, imposta `OPENAI_API_KEY` e `SESSION_SECRET`, poi `npm start`. Apri `http://localhost:3000`. La PWA si installa normalmente tramite HTTPS; localhost è un'eccezione per sviluppo.

## Piano dal solo telefono Android

### 1. Mettere il sito online
1. Dal browser crea un repository privato su https://github.com/.
2. Carica i file di questo ZIP: `index.html`, `styles.css`, `app.js`, `manifest.webmanifest`, `sw.js`, cartella `icons`, `server.js`, `package.json`, `.env.example` e `.gitignore`. Non caricare mai `.env`, chiavi API o database.
3. Su https://render.com/ crea un Web Service collegato al repository. Build command: `npm install`; start command: `npm start`.
4. Nelle variabili d'ambiente di Render configura `NODE_ENV=production`, `SESSION_SECRET` (almeno 32 caratteri casuali), `OPENAI_API_KEY` e `OPENAI_MODEL=gpt-4.1-mini`.
5. Configura la persistenza di SQLite con un disco persistente e `DB_PATH` nel percorso del disco. Per un lancio vero è preferibile un database PostgreSQL gestito; controlla che il piano scelto supporti la persistenza.
6. Verifica HTTPS, login, registrazione e IA sul sito online.

### 2. Installare ReVendo sul tuo Android
1. Apri il sito online in Chrome.
2. Dal menu ⋮ seleziona “Installa app” o “Aggiungi a schermata Home”.
3. Se non appare, controlla HTTPS e manifest. È una PWA installabile, non ancora la pubblicazione su Play Store.

### 3. Preparare l'app Android per Google Play senza computer
1. Quando il sito è online e stabile, apri https://www.pwabuilder.com dal telefono e inserisci l'URL HTTPS pubblico.
2. Risolvi gli avvisi importanti e sostituisci le icone provvisorie con il tuo logo.
3. Segui il flusso per generare il pacchetto Android. Se usa Trusted Web Activity, configura Digital Asset Links usando il package name e il fingerprint esatti forniti dal processo; pubblica il file richiesto in `/.well-known/assetlinks.json`.
4. Scarica il file `.aab` per Play Store se il flusso lo fornisce. Conserva le chiavi di firma al sicuro.
5. In Google Play Console crea l'app, compila scheda, privacy, sicurezza dei dati e classificazione contenuti, quindi carica l'AAB per il test.
6. Per i nuovi account personali soggetti alla regola, Google richiede un test chiuso con almeno 12 tester che rimangano iscritti per 14 giorni consecutivi prima di richiedere la pubblicazione pubblica. Verifica i requisiti effettivi del tuo account.
7. Dopo i test e l'approvazione di Google, pubblica la versione in produzione.

## Budget
- Puoi provare la PWA prima di pagare per Play Store.
- Google Play Console richiede normalmente una quota una tantum di 25 USD per registrare l'account sviluppatore. Perciò il lancio sul Play Store non è completamente gratuito.
- Hosting gratuito può avere limiti e l'API OpenAI può generare costi. Imposta limiti e avvisi di spesa. Un dominio personalizzato è opzionale.

## Prima del lancio pubblico: cose ancora da completare
- Il prototipo salva ancora annunci e preferiti nel browser; non sono condivisi tra tutti gli utenti.
- Non sono ancora presenti un flusso completo e testato per la pubblicazione condivisa degli annunci, caricamento immagini affidabile, chat completa, pagamenti, spedizioni, verifica email, recupero password, moderazione e pannello amministratore.
- Prima di trattare dati reali migra a database gestito, verifica le autorizzazioni su ogni API, aggiungi backup e monitoraggio, testa la sicurezza, prepara privacy policy e condizioni d'uso.
- Le icone `icons/` sono temporanee: sostituiscile con il tuo logo.

Questo progetto è una base tecnica; non è una garanzia di sicurezza né un marketplace pronto per pagamenti o dati sensibili.
