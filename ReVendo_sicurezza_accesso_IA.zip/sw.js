/* ReVendo PWA service worker: network-only, no private data cached. */
self.addEventListener("install", () => self.skipWaiting());
self.addEventListener("activate", (event) => event.waitUntil(self.clients.claim()));
self.addEventListener("fetch", (event) => {
  const request = event.request;
  if (request.method !== "GET" || new URL(request.url).origin !== self.location.origin) return;
  event.respondWith(fetch(request).catch(() => {
    if (request.mode === "navigate") return new Response(
      '<!doctype html><html lang="it"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>ReVendo offline</title><body style="font-family:Arial;padding:2rem"><h1>Sei offline</h1><p>Per usare ReVendo, riconnettiti a Internet e ricarica la pagina.</p></body></html>',
      { headers: { "Content-Type": "text/html; charset=utf-8" }, status: 200 }
    );
    return Response.error();
  }));
});
